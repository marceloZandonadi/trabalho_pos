<?php
include 'BaseDeDados.php';
class BaseDeDadosClass implements BaseDeDados{
    private $nome;
    private $dependencia;
    
    function __construct($nome, SGBD $servidor) {
        $this->nome = $nome;
        $this->dependencia = $servidor;
    }
    
    public function conectar() {
        if($this->tipo == 'mysql'){
            $this->conexao = mysqli_connect($this->dependencia->getEndereco(), $this->dependencia->usuario, $this->dependencia->senha, $this->nome);
            if(!$this->conexao){
                    throw new \Exception(mysqli_connect_error());
            }
        } 
    }

    public function desconectar() {
        if ($this->conexao) {
			mysqli_close($this->conexao);
			$this->conexao = NULL;
		}
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

}