<?php
include '../src/SGBD.php';
include '../classes/Entidade.php';
include '../src/SGBD.class.php';
include '../src/BaseDeDados.class.php';
include '../classes/Produto.php';

$colunas = array('nome', 'preco');
$valores = array('caneta','22.50');

$servidor = new SGBDclass("mysql");
$servidor->setEndereco("localhost");
$servidor->setPorta(3306);
$servidor->usuario = 'root';
$servidor->senha = '';

$base = new BaseDeDadosClass('alfa_oo', $servidor);
$base->tipo = 'mysql';

try{
    $base->conectar();
    var_dump($base);
} catch (Exception $ex) {
    echo $e->getMessage();
}
$produto = new Produto($base);
$produto->nome = 'Teste';
$produto->preco= '10';

$colunas = array('nome','preco');
$valores = array('chinelo','11');
$clausula = 1;
//UPDATE
/*
try{
    $produto->update($colunas, $valores, $clausula);
} catch (Exception $ex) {
    echo $ex;
}
//INSERT
/*
try{
    $produto->create($colunas, $valores);
} catch (Exception $ex) {
    echo $ex->getMessage();
}
//DELETE
*/

try {
    $produto->delete(1);
} catch (Exception $ex) {
    $ex->getMessage();
}

//echo $sgbd->teste;
//$base->setNome("teste");
//echo $base->getNome();
