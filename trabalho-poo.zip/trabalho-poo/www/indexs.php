<?php
session_start();
if($_SESSION['login_admin' != ""]){
    header("location: home");
}else{
    header("location: login");
}
  
?>
