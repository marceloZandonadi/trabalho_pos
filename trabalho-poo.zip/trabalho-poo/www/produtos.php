<?php
	include '../src/SGBD.php';
	include '../classes/Entidade.php';
	include '../src/SGBD.class.php';
	include '../src/BaseDeDados.class.php';
	include '../classes/Produto.php';
	
	$acao   = (isset($_GET['acao'])) ? $_GET['acao'] : '';
	$id   = (isset($_GET['id'])) ? $_GET['id'] : '';
	
	$servidor = new SGBDclass("mysql");
	$servidor->setEndereco("localhost");
	$servidor->setPorta(3306);
	$servidor->usuario = 'root';
	$servidor->senha = '';

	$base = new BaseDeDadosClass('alfa_oo', $servidor);
	$base->tipo = 'mysql';
	$obproduto = new Produto($base);
	
	$acao   = (isset($_GET['acao'])) ? $_GET['acao'] : '';
	$id   = (isset($_GET['id'])) ? $_GET['id'] : '';
  
	try{
		$base->conectar();
		} catch (Exception $ex) {
		echo $e->getMessage();
		
	}
	
	if($acao == "excluir"){
		
		try {
			$obproduto->delete($id);
		} catch (Exception $ex) {
			$ex->getMessage();
		}
	}
	$colunas  = array();
	$clausula = array();
    $obproduto = new Produto($base);
	try{
		$sql = $obproduto->retrieve($colunas, $clausula);
			} catch (Exception $ex) {
		echo $ex->getMessage();
	}
		$base->desconectar();
	
?>

<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Admin 3.0 | 2015</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <script>
      function Deletar(id){
        if (window.confirm("Deseja excluir o produto?")) {
        location.href="?id="+id+"&acao=excluir";
        }
      }
    </script>
  </head>
  <body class="skin-blue">
    <div class="wrapper">

      <?php include_once('inc/header_lateral.php'); ?>

      <div class="content-wrapper">
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Listagem dos Cursos</h3>
                  <div class="box-tools">
                    <form id="Pesquisa" name="Pesquisa" method="Post">
                      <div class="input-group">
                        <input type="text" name="filtro" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Pesquisar"/>
                        <div class="input-group-btn">
                          <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>ID</th>
                      <th>Nome</th>
                      <th>Preço</th>
                      <th>Ação</th>
                    </tr>
                    <?php

                        while($dados_produto = mysqli_fetch_assoc($sql)){?>
                        <tr>
							<td><?=$dados_produto['id']?></td>
							<td><?=$dados_produto['nome']?></td>
							<td><?=$dados_produto['preco']?></td>
							</a></td>
							<td><a href="cadastrar-produto.php?id=<?=$dados_produto['id'];?>"><img src="dist/img/search.png"></a>
							<a href="#" onClick='Deletar(<?=$dados_produto['id']?>)'><img src="dist/img/delete.png" width="15px;"></a></td>
                        </tr>
                      <?php } ?>
                  </table>
                </div>
                <br><br>

              </div>
            </div>
          </div>
        </section>
      </div>

      <?php include_once('inc/foot.php'); ?>

    </div>

    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <script src="dist/js/demo.js" type="text/javascript"></script>
  </body>
</html>
