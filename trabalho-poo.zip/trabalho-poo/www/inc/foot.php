      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>3.0</b>
        </div>
        <strong>Copyright &copy; 2014-2015
      </footer>
