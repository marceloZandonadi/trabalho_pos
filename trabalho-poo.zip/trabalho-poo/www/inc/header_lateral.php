      <header class="main-header">
        <a href="home" class="logo"><b>Admin</b> 3.0</a>
        <nav class="navbar navbar-static-top" role="navigation">
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only"></span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/user.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs">Usuário</span>
                </a>
                <ul class="dropdown-menu">
                  <li class="user-header">
                    <img src="dist/img/user.png" class="img-circle" alt="User Image" />
                  </li>
                  <li class="user-footer">
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <aside class="main-sidebar">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/user.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p>Usuário</p>

              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="header">Menu</li>
  
                <li class="treeview">
                  <a href="#">
                    <i class="fa fa-files-o"></i>
                    <span>Produto</span>
                    <span class="label label-primary pull-right"></span>
                  </a>
                  <ul class="treeview-menu">
                    <li><a href="cadastrar-produto.php"><i class="fa fa-circle-o"></i> Cadastrar</a></li>
                  </ul>
                  <ul class="treeview-menu">
                    <li><a href="produtos.php"><i class="fa fa-circle-o"></i> Ver Listagem</a></li>
                  </ul>
                </li>    
          </ul>
        </section>
      </aside>
