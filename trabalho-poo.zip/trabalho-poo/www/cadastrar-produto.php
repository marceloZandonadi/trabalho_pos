<?php
	include '../src/SGBD.php';
	include '../classes/Entidade.php';
	include '../src/SGBD.class.php';
	include '../src/BaseDeDados.class.php';
	include '../classes/Produto.php';
	
	$servidor = new SGBDclass("mysql");
	$servidor->setEndereco("localhost");
	$servidor->setPorta(3306);
	$servidor->usuario = 'root';
	$servidor->senha = '';

	$base = new BaseDeDadosClass('alfa_oo', $servidor);
	$base->tipo = 'mysql';

  $acao   = (isset($_GET['acao'])) ? $_GET['acao'] : '';
  $id   = (isset($_GET['id'])) ? $_GET['id'] : '';
  $alterar = "";
try{
    $base->conectar();
    //var_dump($base);
	} catch (Exception $ex) {
		echo $e->getMessage();
	}
  if($acao == 'Gravar'){
	  
	$id_produto = (isset($_POST['id_produto'])) ? $_POST['id_produto'] : ''; 
    $produto    = (isset($_POST['produto'])) ? $_POST['produto'] : '';
    $valor 	    = (isset($_POST['valor'])) ? $_POST['valor'] : '';

	$colunas = array('nome', 'preco');
	$valores = array($produto , $valor);
	$clausula = $id_produto;
	
	$obproduto = new Produto($base);
	$obproduto->setNome('produto');
	if($id_produto != ""){
		
	try{	
		$obproduto->update($colunas, $valores, $clausula);
	} catch (Exception $ex) {
		echo $ex;
}
	}else{
		try{
			$obproduto->create($colunas, $valores);
				} catch (Exception $ex) {
			echo $ex->getMessage();
		}
	}
	header("Location: produtos.php");
  }
  if($id != ""){
	  $obproduto = new Produto($base);
	  $colunas   = array('id');
	  $clausula = array($id);
	  try{
		$sql = $obproduto->retrieve($colunas, $clausula);
			} catch (Exception $ex) {
		echo $ex->getMessage();
		}
		$alterar = mysqli_fetch_assoc($sql);
	//	die();
	
  }$base->desconectar();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Admin 3.0 | 2015</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">

      <?php include_once('inc/header_lateral.php'); ?>

      <div class="content-wrapper">
        <section class="content-header">
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Admin</li>
          </ol>
        </section>
        
        <section class="content">
          <div class="row">
            <div class="col-md-6">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">Cadastrar Produto</h3>
                  <form role="form" id="Cadastro" name="Cadastro" method="Post" action="?acao=Gravar" enctype="multipart/form-data">
                    <div class="box-body">
                      <div class="form-group">
					  <input type="hidden" name="id_produto" value="<?php if($alterar) echo $alterar["id"];?>"/>
                        <label for="curso">Produto</label>
                        <input type="text" id="produto" name="produto" class="form-control" placeholder="Nome do Produto" required value="<?php if($alterar)echo $alterar["nome"];?>" />
                      </div>
					  <div class="form-group">
                        <label for="curso">Valor</label>
                        <input type="text" id="valor" name="valor" class="form-control" placeholder="Valor do Produto" required value="<?php if($alterar) echo $alterar["preco"];?>"/>
                      </div>
                    </div>
                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Gravar</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <section>
        <br>
      </div>

      <?php include_once('inc/foot.php'); ?>

    </div>

    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.min.js" type="text/javascript"></script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <script src="dist/js/app.min.js" type="text/javascript"></script>
  </body>
</html>
