<?php

abstract class Entidade{
    abstract public function setEndereco($endereco);

    public function create(){
//        echo __CLASS__."<hr>";
		$entidade = substr(__CLASS__, strrpos(__CLASS__, '\\') + 1);

		$atributos = get_object_vars($this);

//		$atributos = array_diff_key($atributos, $this->atributosIgnorados);
		$colunas = array_keys($atributos);
		$valores = array_values($atributos);
		
		//var_dump($valores);
//		var_dump($atributos);

		$sql = "INSERT INTO $entidade (".implode(',', $colunas).") VALUES('".implode("','",$valores)."')";
//		mysqli_query($this->dependencia->conexao,$sql);

		if(!mysqli_query(self::$dependencia->conexao,$sql)){
			throw new \Exception(mysqli_error(self::$dependencia->conexao));
			
		}
    }
}