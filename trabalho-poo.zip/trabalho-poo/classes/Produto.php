<?php

class Produto implements Alfa\Abstracao\Entidade
{
     static $id;
    public $nome;
    public $preco;
    static $dependencia;
    //use \Alfa\Traits\Create;
    
    public function create($colunas,$valores)
    {

        //$entidade = substr(__CLASS__, strrpos(__CLASS__, '\\') );
		//$entidade = strtolower ($entidade);
		$entidade = $this->nome;

		$colunas = array_values($colunas);
		$valores = array_values($valores);
	

		$sql = "INSERT INTO $entidade (".implode(',', $colunas).") VALUES('".implode("','",$valores)."')";
		
		if(!mysqli_query(self::$dependencia->conexao,$sql)){
				throw new \Exception(mysqli_error(self::$dependencia->conexao));
		}
    }
    
    public function delete($clausula) 
    {
        $entidade = substr(__CLASS__, strrpos(__CLASS__, '\\') );
        $entidade = strtolower ($entidade);
        $sql = "DELETE FROM $entidade WHERE id = $clausula";
        
        if(!mysqli_query(self::$dependencia->conexao,$sql)){
                    throw new \Exception(mysqli_error(self::$dependencia->conexao));
            }
    }
   
    
    public function __construct(BaseDeDados $base) 
    {
        self::$dependencia = $base;
    }

    

    public function getNome() {
        return $this->nome;
    }

    public function retrieve($colunas, $clausula) {
        $entidade = substr(__CLASS__, strrpos(__CLASS__, '\\') );
        $entidade = strtolower ($entidade);
		$contagem = count($colunas);
		$sql = "SELECT * FROM $entidade  ";
		$i  =  0;
        while ($i < $contagem ){
            if($i==0){
                $sql .= "WHERE $colunas[$i] = '$clausula[$i]' ";
            }else{
                $sql .= ", $colunas[$i] = '$clausula[$i]' ";
            }
            $i++;
        }
		$retrieve = mysqli_query(self::$dependencia->conexao,$sql);
		if(!$retrieve){
                    throw new \Exception(mysqli_error(self::$dependencia->conexao));
            }
			return $retrieve;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function update($colunas, $valores, $clausula) {
        $entidade = substr(__CLASS__, strrpos(__CLASS__, '\\') );
        $contagem = count($colunas);
        $sql = "UPDATE $entidade SET ";
        $i  =  0;
        while ($i < $contagem ){
            if($i==0){
                $sql .= " $colunas[$i] = '$valores[$i]' ";
            }else{
                $sql .= ", $colunas[$i] = '$valores[$i]' ";
            }
            $i++;
        }
        $sql .= "WHERE id = ".$clausula;

        if(!mysqli_query(self::$dependencia->conexao,$sql)){
                    throw new \Exception(mysqli_error(self::$dependencia->conexao));
            }
    }

}